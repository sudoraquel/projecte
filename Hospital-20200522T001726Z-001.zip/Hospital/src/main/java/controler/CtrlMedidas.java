/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controler;

import java.awt.event.ActionEvent;
import model.Paciente;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;
import model.ConsultasMedidas;
import model.Medidas;
import view.frmAñadirMedidas;
import view.frmMedidas;
import view.frmRepresentarMedidas;

/**
 *
 * @author guillermosantiago
 */
public class CtrlMedidas implements ActionListener{

    private Paciente paciente;
    private Medidas medidas;
    private ConsultasMedidas cMedidas;
    private CtrlMedidas controlMedidas;
    private frmAñadirMedidas frmAñadirMedidas;
    private frmMedidas frmMedidas;
    private frmRepresentarMedidas frmRepresentarMedidas;

    public CtrlMedidas(Paciente paciente, Medidas medidas, frmMedidas frmMedidas) {
        this.paciente = paciente;
        this.medidas = medidas;
        this.frmAñadirMedidas = new frmAñadirMedidas();
        this.frmMedidas = new frmMedidas(this.paciente);
        this.frmRepresentarMedidas = new frmRepresentarMedidas();
        this.cMedidas = new ConsultasMedidas();
        
        
        this.frmMedidas.btnBuscar.addActionListener(this);
        this.frmAñadirMedidas.btnGuardar.addActionListener(this);
        this.frmRepresentarMedidas.btnEliminar.addActionListener(this);
        
        iniciar();
    }

    
    public void iniciar() {
        this.frmMedidas.setTitle("Medidas");
        this.frmMedidas.setLocationRelativeTo(null);
        this.frmMedidas.setVisible(true);

    }

    @Override
    public void actionPerformed(ActionEvent e) {



    }
}

