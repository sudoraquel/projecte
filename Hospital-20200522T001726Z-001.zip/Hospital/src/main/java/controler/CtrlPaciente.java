/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controler;

import model.Paciente;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;
import model.ConsultasHospital;
import model.ConsultasMedidas;
import model.ConsultasPaciente;
import model.Medidas;
import view.frmHospital;
import view.frmMedidas;
import view.frmPaciente;

/**
 *
 * @author guillermosantiago
 */
public class CtrlPaciente implements ActionListener {

    private Paciente paciente;
    private ConsultasPaciente cPaciente;
    private frmPaciente frm;
    
    private ConsultasHospital consultasHospital = new ConsultasHospital();
    private CtrlHospital controlHospital;
    private frmHospital frmHospital;
    
    private frmMedidas frmMedidas;
    private CtrlMedidas controlMedidas;
    private ConsultasMedidas consultasMedidas = new ConsultasMedidas();
    private Medidas medidas;
    
    private boolean Modificado;
    

    public CtrlPaciente(Paciente pac, frmPaciente frm) {

        this.paciente=pac;
        this.cPaciente = new ConsultasPaciente();
        this.frm = new frmPaciente(pac);
        

        this.frm.btnModificarHabitacion.addActionListener(this);
        this.frm.btnModificarDoctor.addActionListener(this);
        this.frm.btnModificarUnidad.addActionListener(this);
        this.frm.btnModificarPatologia.addActionListener(this);
        this.frm.btnModificarDieta.addActionListener(this);
        this.frm.btnModificarIncontinencia.addActionListener(this);
        
        this.frm.btnAlta.addActionListener(this);
        this.frm.btnDefuncion.addActionListener(this);
        this.frm.btnAtras.addActionListener(this);
        this.frm.btnMedidas.addActionListener(this);
        
        
        
        iniciar();

    }

    public void iniciar() {
        frm.setTitle("Paciente");
        frm.setLocationRelativeTo(null);
        frm.labelPacienteId.setVisible(false);
        frm.setVisible(true);
        
        frm.labelPacienteId.setText(Integer.toString(this.paciente.getIdPaciente()));
        frm.txtNombre.setText(this.paciente.getNombre());
        frm.labelNumero.setText(Integer.toString(this.paciente.getNumero()));
        frm.txtGenero.setText(this.paciente.getGenero());
        frm.txtHabitacion.setText(Integer.toString(this.paciente.getHabitacion()));
        frm.txtDoctor.setText(this.paciente.getDoctor());
        frm.txtUnidad.setText(this.paciente.getUnidad());
        frm.txtPatologia.setText(this.paciente.getPatologia());
        frm.txtDieta.setText(this.paciente.getDieta());
        frm.txtIncontinencia.setText(this.paciente.getIncontinencia());
        
        this.frm.setVisible(true);

    }

    @Override
    public void actionPerformed(ActionEvent e) {

        if (e.getSource() == this.frm.btnAlta || e.getSource() == this.frm.btnDefuncion) {
            
            this.paciente.setIdPaciente(Integer.parseInt(frm.labelPacienteId.getText()));

            if (this.cPaciente.eliminar(this.paciente.getIdPaciente())) {
                JOptionPane.showMessageDialog(null, "Pacient eliminat del llistat");
                controlHospital = new CtrlHospital(this.frmHospital);
                this.frm.setVisible(false);
                
            } else {
                JOptionPane.showMessageDialog(null, "Acció no realitzada correctament");
            }
        }
        
        if(e.getSource()==this.frm.btnAtras){
            this.paciente.setNumero(Integer.parseInt(this.frm.labelNumero.getText()));
            
            if(this.cPaciente.modificar(this.paciente)){
                this.frmHospital = new frmHospital();
                this.controlHospital = new CtrlHospital(this.frmHospital);
                this.frm.setVisible(false);
            } else {
                JOptionPane.showMessageDialog(null, "No se ha podido registrar correctamente");
            }
            
        }
        
        if(e.getSource()==this.frm.btnMedidas){
            if(this.cPaciente.modificar(this.paciente)){
                this.frmMedidas = new frmMedidas(this.paciente);
                this.controlMedidas = new CtrlMedidas(this.paciente, this.medidas, this.frmMedidas);
                this.frm.setVisible(false);
                          
            } else {
                JOptionPane.showMessageDialog(null, "No se ha podido guardar correctamente");
            }
        
        }

    }
}
