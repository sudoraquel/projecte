/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author guillermosantiago
 */
public class ConsultasHospital extends Conexion{
    
    public ConsultasHospital(){
        
    }
    
    public boolean buscar(Paciente paciente) {

        PreparedStatement ps = null;
        ResultSet rs = null;
        Connection con = getConexion();

        String sql = "SELECT * FROM Hospital.paciente WHERE numero=?";

        try {
            ps = con.prepareStatement(sql);

            ps.setInt(1, paciente.getNumero());

            rs = ps.executeQuery();

            if (rs.next()) {
                
                paciente.setIdPaciente(Integer.parseInt(rs.getString("idpaciente")));
                paciente.setNombre(rs.getString("nombre"));
                paciente.setNumero(Integer.parseInt(rs.getString("numero")));
                paciente.setGenero(rs.getString("genero"));
                paciente.setHabitacion(Integer.parseInt(rs.getString("temperatura")));
                paciente.setDoctor(rs.getString("doctor"));
                paciente.setUnidad(rs.getString("unidad"));
                paciente.setPatologia(rs.getString("patologia"));
                paciente.setDieta(rs.getString("dieta"));
                paciente.setIncontinencia(rs.getString("incontinencia"));
                        
                return true;
            }
            return false;

        } catch (SQLException e) {

            System.err.println(e);
            return false;

        }
        finally {
            try {
                con.close();
                ps.close();
                rs.close();

            } catch (SQLException e) {
                System.err.println(e);
            }
        }

    }
    
    public boolean registrar(Paciente paciente){
        PreparedStatement ps = null;
        Connection con = getConexion();

        String sql = "INSERT INTO Hospital.paciente (nombre, numero, genero, habitacion, doctor, unidad, patologia, dieta, incontinencia) VALUES (?,?,?,?,?,?,?,?,?)";

        try {

            ps = con.prepareStatement(sql);

            ps.setString(1, paciente.getNombre());
            ps.setInt(2, paciente.getNumero());
            ps.setString(3, paciente.getGenero());
            ps.setInt(4, paciente.getHabitacion());
            ps.setString(5, paciente.getDoctor());
            ps.setString(6, paciente.getUnidad());
            ps.setString(7, paciente.getPatologia());
            ps.setString(8, paciente.getDieta());
            ps.setString(9, paciente.getIncontinencia());

            ps.execute();
            return true;

        } catch (SQLException e) {

            e.printStackTrace(System.out);
            
            return false;

        } finally {
            try {

                con.close();

            } catch (SQLException e) {
                System.err.println(e);
            }
        }

    }
    
}
