/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author guillermosantiago
 */
public class ConsultasMedicinas extends Conexion{
    
    public ConsultasMedicinas(){
        
    }
    
    public boolean modificar(Medicina medicina){
        
        PreparedStatement ps = null;
        Connection con = getConexion();

        String sql = "UPDATE Hospital.medicina SET idpaciente=?, nombre=?, cantidad=? WHERE idmedicina=?";

        try {

            ps = con.prepareStatement(sql);
            ps.setInt(1, medicina.getIdPaciente());
            ps.setString(2, medicina.getNombre());
            ps.setInt(3, medicina.getCantidad());
           
            ps.setInt(4, medicina.getIdMedicina());

            ps.execute();
            return true;

        } catch (SQLException e) {

            System.err.println(e);
            return false;

        } finally {
            try {

                con.close();

            } catch (SQLException e) {
                System.err.println(e);
            }
        }        
    }
    
    public boolean registrar(Paciente paciente, Medicina medicina) {

        PreparedStatement ps = null;
        Connection con = getConexion();

        String sql = "INSERT INTO Hospital.medicina (idpaciente, nombre, cantidad) VALUES (?,?,?)";

        try {

            ps = con.prepareStatement(sql);

            ps.setInt(1, paciente.getIdPaciente());
            ps.setString(2, medicina.getNombre());
            ps.setInt(3, medicina.getCantidad());
            
            ps.execute();
            return true;

        } catch (SQLException e) {

            System.err.println(e);
         
            return false;

        } finally {
            try {

                con.close();

            } catch (SQLException e) {
                System.err.println(e);
            }
        }

    }

    public boolean eliminar(Medicina medicina) {

        PreparedStatement ps = null;
        Connection con = getConexion();

        String sql = "DELETE FROM Hospital.medicina WHERE idmedicina=?";

        try {

            ps = con.prepareStatement(sql);
            
           
            ps.setInt(1, medicina.getIdMedicina());
            
            ps.execute();
            return true;

        } catch (SQLException e) {

            System.err.println(e);
            return false;

        } finally {
            try {

                con.close();

            } catch (SQLException e) {
                System.err.println(e);
            }
        }

    }

    public boolean buscar(Paciente paciente, Medicina medicina) {

        PreparedStatement ps = null;
        ResultSet rs = null;
        Connection con = getConexion();

        String sql = "SELECT * FROM Hospital.medicina WHERE idpaciente=?";

        try {
            ps = con.prepareStatement(sql);

            ps.setInt(1, paciente.getIdPaciente());

            rs = ps.executeQuery();

            if (rs.next()) {
                
                medicina.setIdPaciente(Integer.parseInt(rs.getString("idaciente")));
                medicina.setIdMedicina(Integer.parseInt(rs.getString("idelemento")));
                medicina.setNombre(rs.getString("nombre"));
                medicina.setCantidad(Integer.parseInt(rs.getString("cantidad")));
                
                return true;
            }
            return false;

        } catch (SQLException e) {

            System.err.println(e);
            return false;

        }
        finally {
            try {
                con.close();
                ps.close();
                rs.close();

            } catch (SQLException e) {
                System.err.println(e);
            }
        }

    }
    
}
