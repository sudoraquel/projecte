/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

/**
 *
 * @author guillermosantiago
 */
public class ConsultasModificar extends Conexion{
    
     public boolean modificar(Paciente paciente, int i) {

        PreparedStatement ps = null;
        Connection con = getConexion();

        String sql1 = "UPDATE Hospital.paciente SET ";
        String sql2= " WHERE id=?";
        String request = "";

        switch(i){
            case 1:
                request= "habitacion=?";
                break;
            case 2:
                request = "doctor=?";
                break;
            case 3:
                request = "unidad=?";
                break;
            case 4:
                request = "patologia=?";
                break;
            case 5:
                request = "dieta=?";
                break;
            case 6:
                request = "incontinencia=?";
                break;
                        
        }
        
        try {

            ps = con.prepareStatement(sql1+request+sql2);


            switch(i){
            case 1:
                ps.setInt(1, paciente.getHabitacion());
                break;
            case 2:
                ps.setString(1, paciente.getDoctor());
                break;
            case 3:
                ps.setString(1, paciente.getUnidad());
                break;
            case 4:
                ps.setString(1, paciente.getPatologia());
                break;
            case 5:
                ps.setString(1, paciente.getDieta());
                break;
            case 6:
                ps.setString(1, paciente.getIncontinencia());
                break;
                        
        }
           
            ps.setInt(2, paciente.getIdPaciente());

            ps.execute();
            return true;

        } catch (SQLException e) {

            System.err.println(e);
            return false;

        } finally {
            try {

                con.close();

            } catch (SQLException e) {
                System.err.println(e);
            }
        }

    }
    
}
