/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author guillermosantiago
 */
public class ConsultasPaciente extends Conexion {
    
    public ConsultasPaciente()
    {
        
    }    

    public boolean modificar(Paciente paciente, int i) {

        PreparedStatement ps = null;
        Connection con = getConexion();

        String sql1 = "UPDATE Hospital.paciente SET ";
        String sql2= " WHERE idpaciente=?";
        String request = "";

        switch(i){
            case 1:
                request= "habitacion=?";
                break;
            case 2:
                request = "doctor=?";
                break;
            case 3:
                request = "unidad=?";
                break;
            case 4:
                request = "patologia=?";
                break;
            case 5:
                request = "dieta=?";
                break;
            case 6:
                request = "incontinencia=?";
                break;
                        
        }
        
        try {

            ps = con.prepareStatement(sql1+request+sql2);


            switch(i){
            case 1:
                ps.setInt(1, paciente.getHabitacion());
                break;
            case 2:
                ps.setString(1, paciente.getDoctor());
                break;
            case 3:
                ps.setString(1, paciente.getUnidad());
                break;
            case 4:
                ps.setString(1, paciente.getPatologia());
                break;
            case 5:
                ps.setString(1, paciente.getDieta());
                break;
            case 6:
                ps.setString(1, paciente.getIncontinencia());
                break;
                        
        }
           
            ps.setInt(2, paciente.getIdPaciente());

            ps.execute();
            return true;

        } catch (SQLException e) {

            System.err.println(e);
            return false;

        } finally {
            try {

                con.close();

            } catch (SQLException e) {
                System.err.println(e);
            }
        }

    }
    
    public boolean modificar(Paciente paciente){
        PreparedStatement ps = null;
        Connection con = getConexion();
        
        String sql = "UPDATE Hospital.paciente SET habitacion=?, doctor=?, unidad=?, patologia=?, dieta=?, incontinencia=? WHERE idpaciente=?";
        
        
        try {

            ps = con.prepareStatement(sql);
            
            ps.setInt(1, paciente.getHabitacion());
            ps.setString(2, paciente.getDoctor());
            ps.setString(3, paciente.getUnidad());
            ps.setString(4, paciente.getPatologia());
            ps.setString(5, paciente.getDieta());
            ps.setString(6, paciente.getIncontinencia());
           
            ps.setInt(7, paciente.getIdPaciente());

            ps.execute();
            return true;

        } catch (SQLException e) {

            System.err.println(e);
            return false;

        } finally {
            try {

                con.close();

            } catch (SQLException e) {
                System.err.println(e);
            }
        }
    }

    public boolean eliminar(int idPaciente) {

        PreparedStatement ps = null;
        Connection con = getConexion();

        String sql = "DELETE FROM Hospital.paciente WHERE idpaciente=?";
        
        try {

            ps = con.prepareStatement(sql);

            ps.setInt(1, idPaciente);

            ps.execute();
            return true;

        } catch (SQLException e) {

            System.err.println(e);
            return false;

        } finally {
            try {

                con.close();

            } catch (SQLException e) {
                System.err.println(e);
            }
        }

    }
    
    
}
