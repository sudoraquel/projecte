/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author guillermosantiago
 */
public class Medicina {
    
    private int idPaciente;
    private int idMedicina;
    private String nombre;
    private int cantidad;

    public Medicina(){
        this.idPaciente =0;
        this.idMedicina = 0;
        this.nombre = "";
        this.cantidad = 0;
    }
    public int getIdPaciente() {
        return idPaciente;
    }

    public int getIdMedicina() {
        return idMedicina;
    }

    public String getNombre() {
        return nombre;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setIdPaciente(int idPaciente) {
        this.idPaciente = idPaciente;
    }

    public void setIdMedicina(int idMedicina) {
        this.idMedicina = idMedicina;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }

    
            
}
