/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author guillermosantiago
 */
public class Medidas {
    
    private String Date;
    private int Sistolica;
    private int Diastolica;
    private int Temperatura;
    private int Peso;
    private int idPaciente;
    private int idMedida;
    
    public Medidas(){
        this.Date = "";
        this.Sistolica = 0;
        this.Diastolica =0;
        this.Temperatura =0;
        this.Peso =0;
        this.idPaciente =0;
        this.idMedida=0;
    }
    public Medidas(String Date, int Sistolica, int Diastolica, int Temperatura, int Peso, int idPaciente, int idMedida){
        
        this.Date = Date;
        this.Sistolica = Sistolica;
        this.Diastolica = Diastolica;
        this.Temperatura = Temperatura;
        this.Peso = Peso;
        this.idPaciente = idPaciente;
        this.idMedida = idMedida;
        
    }

    public void setIdMedida(int idMedida) {
        this.idMedida = idMedida;
    }

    public int getIdMedida() {
        return idMedida;
    }

    public void setDate(String Date) {
        this.Date = Date;
    }

    public void setSistolica(int Sistolica) {
        this.Sistolica = Sistolica;
    }

    public void setDiastolica(int Diastolica) {
        this.Diastolica = Diastolica;
    }

    public void setTemperatura(int Temperatura) {
        this.Temperatura = Temperatura;
    }

    public void setPeso(int Peso) {
        this.Peso = Peso;
    }

    public void setIdPaciente(int idPaciente) {
        this.idPaciente = idPaciente;
    }

    public String getDate() {
        return Date;
    }

    public int getSistolica() {
        return Sistolica;
    }

    public int getDiastolica() {
        return Diastolica;
    }

    public int getTemperatura() {
        return Temperatura;
    }

    public int getPeso() {
        return Peso;
    }

    public int getIdPaciente() {
        return idPaciente;
    }
    
}
