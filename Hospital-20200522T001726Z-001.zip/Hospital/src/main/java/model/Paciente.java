/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author guillermosantiago
 */
public class Paciente {
    
    private int idPaciente;
    private String Nombre;
    private int Numero;
    private String Genero;
    private int Habitacion;
    private String Doctor;
    private String Unidad;
    private String Patologia;
    private String Dieta;
    private String Incontinencia;
    
    public Paciente(){
        this.idPaciente=-1;
        this.Nombre = null;
        this.Numero = -1;
        this.Genero = null;
        this.Habitacion = -1;
        this.Doctor = null;
        this.Unidad = null;
        this.Patologia = null;
        this.Dieta = null;
        this.Incontinencia = null;
        
    }

    public void setIdPaciente(int idPaciente) {
        this.idPaciente = idPaciente;
    }

    public void setNombre(String Nombre) {
        this.Nombre = Nombre;
    }

    public void setNumero(int Numero) {
        this.Numero = Numero;
    }

    public void setGenero(String Genero) {
        this.Genero = Genero;
    }

    public void setHabitacion(int Habitacion) {
        this.Habitacion = Habitacion;
    }

    public void setDoctor(String Doctor) {
        this.Doctor = Doctor;
    }

    public void setUnidad(String Unidad) {
        this.Unidad = Unidad;
    }

    public void setPatologia(String Patologia) {
        this.Patologia = Patologia;
    }

    public void setDieta(String Dieta) {
        this.Dieta = Dieta;
    }

    public void setIncontinencia(String Incontinencia) {
        this.Incontinencia = Incontinencia;
    }

    
    
    public int getIdPaciente() {
        return idPaciente;
    }

    public String getNombre() {
        return Nombre;
    }

    public int getNumero() {
        return Numero;
    }

    public String getGenero() {
        return Genero;
    }

    public int getHabitacion() {
        return Habitacion;
    }

    public String getDoctor() {
        return Doctor;
    }

    public String getUnidad() {
        return Unidad;
    }

    public String getPatologia() {
        return Patologia;
    }

    public String getDieta() {
        return Dieta;
    }

    public String getIncontinencia() {
        return Incontinencia;
    }
    
    public void setModificar(String modificar, int i){
    switch(i){
            case 1:
                this.setHabitacion(Integer.parseInt(modificar));
                break;
            case 2:
                this.setDoctor(modificar);
                break;
            case 3:
                this.setUnidad(modificar);
                break;
            case 4:
                this.setPatologia(modificar);
                break;
            case 5:
                this.setDieta(modificar);
                break;
            case 6:
                this.setIncontinencia(modificar);
                break;
                        
        }
    }
    
    
}
