/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controler;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import model.ConsultasHospital;
import view.frmHospital;

/**
 *
 * @author guillermosantiago
 */
public class CtrlHospital implements ActionListener{
    
    private ConsultasHospital consultasHospital;
    private frmHospital frmHospital;
    
    public CtrlHospital(frmHospital frmHospital){
        this.consultasHospital = new ConsultasHospital();
        this.frmHospital = frmHospital;
        
        this.frmHospital.btnBuscar.addActionListener(this);
        this.frmHospital.btnNuevo.addActionListener(this);
        iniciar();
        
    }
    
    public void iniciar(){
        frmHospital.setTitle("Gestio de pacients");
        frmHospital.setLocationRelativeTo(null);
        frmHospital.setVisible(true);
    }
    
    @Override
    public void actionPerformed(ActionEvent e){
        
    }
}
