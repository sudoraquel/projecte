/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controler;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import model.Medicina;
import model.Paciente;
import view.frmAñadirMedicina;
import view.frmMedicinas;
import view.frmRepresentarMedicina;

/**
 *
 * @author guillermosantiago
 */
public class CtrlMedicinas implements ActionListener{
    
    private Paciente paciente;
    private Medicina medicina;
    
    private frmMedicinas frmMedicina;
    private frmRepresentarMedicina frmRepresentarMedicina;
    private frmAñadirMedicina frmAñadirMedicina;
    
    public CtrlMedicinas(Paciente paciente, Medicina medicina){
        this.paciente = paciente;
        this.medicina = medicina;
        this.frmMedicina = new frmMedicinas(this.paciente);
        
        this.frmAñadirMedicina = new frmAñadirMedicina();
        this.frmRepresentarMedicina = new frmRepresentarMedicina();
        
        this.frmRepresentarMedicina.btnEliminar.addActionListener(this);
        this.frmAñadirMedicina.btnGuardar.addActionListener(this);
        
        iniciar();
    }
    
    public void iniciar(){
        this.frmMedicina.setTitle("Medicació del pacient");
        this.frmMedicina.setLocationRelativeTo(null);
        this.frmMedicina.setVisible(true);
    }
    
    @Override
    public void actionPerformed(ActionEvent e){
        
    }
    
    
}
