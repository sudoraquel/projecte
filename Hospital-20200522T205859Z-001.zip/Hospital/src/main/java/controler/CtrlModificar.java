/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controler;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;

import model.ConsultasPaciente;
import model.Paciente;
import view.frmModificar;
import view.frmPaciente;

/**
 *
 * @author guillermosantiago
 */
public class CtrlModificar implements ActionListener{
    private Paciente paciente = new Paciente();
    private ConsultasPaciente consultasPaciente = new ConsultasPaciente();
    private frmModificar frmModificar;
    private CtrlPaciente controlPaciente;
    private frmPaciente frmPaciente;
    
   
    public CtrlModificar(Paciente paciente, frmModificar frmModificar, int i){
        this.paciente=paciente;
        this.frmModificar = frmModificar;
        this.frmModificar.btnGuardarModificado.addActionListener(this);
        this.frmModificar = new frmModificar(i, this.paciente);
        iniciar(i);
        
        
    }
    
    public void iniciar(int elemento){
        switch(elemento){
            case 1:
                frmModificar.setTitle("Modificar habitacion");
                frmModificar.labelTitulo.setText("Modificar habitacion");
                frmModificar.labelModificar.setText("Nueva habitacion: ");
       
                break;
            case 2:
                frmModificar.setTitle("Modificar doctor");
                frmModificar.labelTitulo.setText("Modificar doctor");
                frmModificar.labelModificar.setText("Nuevo/a doctor/a: ");
                
                
                break;
            case 3:
                frmModificar.setTitle("Modificar unidad");
                frmModificar.labelTitulo.setText("Modificar unidad");
                frmModificar.labelModificar.setText("Nueva unidad: ");
                
                break;
            case 4:
                frmModificar.setTitle("Modificar patologia");
                frmModificar.labelTitulo.setText("Modificar patologia");
                frmModificar.labelModificar.setText("Nueva patologia: ");
                
                break;
            case 5:
                frmModificar.setTitle("Modificar dieta");
                frmModificar.labelTitulo.setText("Modificar dieta");
                frmModificar.labelModificar.setText("Nueva dieta: ");
                
                break;
            case 6:
                frmModificar.setTitle("Modificar incontinencia");
                frmModificar.labelTitulo.setText("Modificar incontinencia");
                frmModificar.labelModificar.setText("Nueva incontinencia: ");
                
                break;
                        
        }
        this.frmModificar.labelModificarId.setText(Integer.toString(elemento));
        this.frmModificar.labelModificarId.setVisible(false);
        this.frmModificar.setLocationRelativeTo(null);
        this.frmModificar.setVisible(true);
    }
    
    @Override
    public void actionPerformed(ActionEvent e){
        if(e.getSource()==this.frmModificar.btnGuardarModificado){
            int i = Integer.parseInt(this.frmModificar.labelModificarId.getText());
            this.paciente.setModificar(this.frmModificar.txtModificar.getText(), i);

            
            if(this.consultasPaciente.modificar(this.paciente, i)){
                JOptionPane.showMessageDialog(null, "Modificado correctamente");
                this.controlPaciente = new CtrlPaciente(this.paciente, this.frmPaciente);
                this.frmModificar.setVisible(false);
                
            } else{
                JOptionPane.showMessageDialog(null, "No se ha podido modificar correctamente");
            }
        }
        
        
    }

    
    
    
}
