/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author guillermosantiago
 */
public class ConsultasMedidas extends Conexion {

    public ConsultasMedidas() {

    }

    public boolean eliminarAll(int idPaciente) {

        PreparedStatement ps = null;
        Connection con = getConexion();

        String sql = "DELETE FROM Hospital.medidas WHERE idpaciente=?";

        try {

            ps = con.prepareStatement(sql);

            ps.setInt(1, idPaciente);

            ps.execute();
            return true;

        } catch (SQLException e) {

            System.err.println(e);
            return false;

        } finally {
            try {

                con.close();

            } catch (SQLException e) {
                System.err.println(e);
            }
        }

    }

    public boolean registrar(Medidas medidas) {

        PreparedStatement ps = null;
        Connection con = getConexion();

        String sql = "INSERT INTO Hospital.medidas (idPaciente, data, sistolica, diastolica, temperatura, peso) VALUES (?,?,?,?,?,?)";

        try {

            ps = con.prepareStatement(sql);

            ps.setInt(1, medidas.getIdPaciente());
            ps.setString(2, medidas.getDate());
            ps.setInt(3, medidas.getSistolica());
            ps.setInt(4, medidas.getDiastolica());
            ps.setInt(5, medidas.getTemperatura());
            ps.setInt(6, medidas.getPeso());

            ps.execute();
            return true;

        } catch (SQLException e) {

            e.printStackTrace(System.out);

            return false;

        } finally {
            try {

                con.close();

            } catch (SQLException e) {
                System.err.println(e);
            }
        }

    }

    public boolean eliminar(Medidas medidas) {

        PreparedStatement ps = null;
        Connection con = getConexion();

        String sql = "DELETE FROM Hospital.medidas WHERE idmedida=?";

        try {

            ps = con.prepareStatement(sql);

            ps.setInt(1, medidas.getIdMedida());

            ps.execute();
            return true;

        } catch (SQLException e) {

            System.err.println(e);
            return false;

        } finally {
            try {

                con.close();

            } catch (SQLException e) {
                System.err.println(e);
            }
        }

    }

    public boolean buscar(Medidas medidas) {

        PreparedStatement ps = null;
        ResultSet rs = null;
        Connection con = getConexion();

        String sql = "SELECT * FROM Hospital.medidas WHERE idmedida=?";

        try {
            ps = con.prepareStatement(sql);

            ps.setInt(1, medidas.getIdMedida());

            rs = ps.executeQuery();

            if (rs.next()) {

                medidas.setIdPaciente(Integer.parseInt(rs.getString("idpaciente")));
                medidas.setDate(rs.getString("data"));
                medidas.setSistolica(Integer.parseInt(rs.getString("sistolica")));
                medidas.setDiastolica(Integer.parseInt(rs.getString("diastolica")));
                medidas.setTemperatura(Integer.parseInt(rs.getString("temperatura")));
                medidas.setPeso(Integer.parseInt(rs.getString("peso")));

                return true;
            }
            return false;

        } catch (SQLException e) {

            System.err.println(e);
            return false;

        } finally {
            try {
                con.close();
                ps.close();
                rs.close();

            } catch (SQLException e) {
                System.err.println(e);
            }
        }

    }

}
