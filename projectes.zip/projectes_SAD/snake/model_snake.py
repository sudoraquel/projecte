import pygame 
import random 
import controller_snake
import view_snake
import threading


WIN_WIDTH = 600
WIN_HEIGHT = 600
DELAY = 0.15
RED = (255, 0, 0)
GREEN1 = (191, 255, 0)
GREEN2 = (0, 255, 0)
PURPLE =  (204, 153, 255)
ObjectSize = 20
all_sprites = pygame.sprite.Group()
obstacles = pygame.sprite.Group()


#set_timer(TICK, T) T= 100ms
# direccio en vector x,y normal (1,0) i sumar el event que tenim (si es 0 la suma vol dir que es direcc contraria)


class Block(pygame.sprite.Sprite):
    def __init__(self, start, head = False, color= GREEN1):
        pygame.sprite.Sprite.__init__(self)
        
        self.head = head
        self.image = pygame.Surface([ObjectSize, ObjectSize])
        self.image.fill(color)

        if self.head:
            circleMiddle = (5, 5)
            circleMiddle2 = (15, 5)
            pygame.draw.circle(self.image, (0,0,0), circleMiddle, 3)
            pygame.draw.circle(self.image, (0,0,0), circleMiddle2, 3)

        self.rect = self.image.get_rect()
        self.rect.x = start[0]
        self.rect.y = start[1]

                        

class Troncho(pygame.sprite.Sprite):
    def __init__(self, color = PURPLE):
        pygame.sprite.Sprite.__init__(self)
        self.image = pygame.Surface([ObjectSize, ObjectSize])
        pygame.draw.circle(self.image, color, [10,10], 10)
        self.rect = self.image.get_rect()
    def randomPos(self, group):
        while True:
            self.rect.x = random.randrange(ObjectSize,WIN_WIDTH,ObjectSize)
            self.rect.y = random.randrange(ObjectSize,WIN_HEIGHT,ObjectSize)
            collide = pygame.sprite.spritecollideany(self, group)
            if not collide:
                break

class Snake(object): 
    body_group = pygame.sprite.Group()
    body = []
    def __init__(self, pos):
        
        self.head = Block(pos, True, GREEN2)
        self.body_group.add(self.head)
        all_sprites.add(self.head)
        self.direction = [1 ,0]
        self.eaten = False 
        self.key = controller_snake.Detection()
        self.ok = True

    

    # Aquesta es la funcio principal que fa que a cada tic de rellotge la serp es mogui i es on apliquem
    # la deteccio de colisions, l'augment del tamany de la serp y es llegeix la tecla que es prem per 
    # fer els canvis de direccio que pertoquin
    def sum(self, vect):
        aux = [self.direction[0]+vect[0], self.direction[1]+vect[1]]
        print(self.direction)
        print(vect)
        print(aux)
        if aux == [0, 0] or vect ==[0, 0]:
            return False
        else: 
            return True
    
    def move(self, apple):
        detect = self.key.keyDetection()
        accept = self.sum(detect)
        print(accept)
        if accept:
            self.direction = detect
        #pygame.time.set_timer(self.key.keyDetection, 100)
        self.bodySize = len(self.body)
        
        #Si eaten es Fals vol dir que ens movem sense afegir segment per tant posem el ultim segment
        #a la posicio del cap i reordenem el conjunt
        if not self.eaten and self.bodySize>0:   

            self.body[-1].rect.x = self.head.rect.x
            self.body[-1].rect.y = self.head.rect.y
            self.body.insert(0, self.body.pop())
            
        elif self.eaten:
            
            self.body_group.add(self.head)
            self.newSegment()
            apple.randomPos(self.body_group)
        
        if self.direction == [1, 0]: 
            self.head.rect.x += ObjectSize
        elif self.direction == [-1, 0]: 
            self.head.rect.x -= ObjectSize
        elif self.direction == [0, 1]: 
            self.head.rect.y -= ObjectSize
        elif self.direction == [0, -1]: 
            self.head.rect.y += ObjectSize

        self.eaten = False

        if self.body_group.has(self.head):
            self.body_group.remove(self.head)

        self.collisionDetect()
        self.eaten = self.eat(apple)

    #Fa les comparacions de la posicio del cap de la serp per saber si esta colisionant amb qualsevol cosa
    def collisionDetect(self):

        col = pygame.sprite.spritecollideany(self.head, self.body_group)
        if col: 
            self.ok = False
        elif self.head.rect.x < 0 or self.head.rect.x > (WIN_WIDTH-ObjectSize+10):
            self.ok = False
        elif self.head.rect.y < 0 or self.head.rect.y > (WIN_HEIGHT-ObjectSize+10):
            self.ok = False
        elif pygame.sprite.spritecollideany(self.head, obstacles):
            self.ok = False
    # Funcio que ens permet saber si el cap esta en la mateixa posicio que la poma i per tant 
    # se la ha menjat

    def eat(self, apple):
        if self.head.rect.x == apple.rect.x and self.head.rect.y == apple.rect.y:
            return True 
        else: 
            return False 
    # Crea un nou segment i el posa a la posicio antiga del cap abans de que aquest es mogui
    def newSegment(self):

        pos = [self.head.rect.x, self.head.rect.y]
        newSegment = Block(pos)
        self.body.insert(0, newSegment)
        self.body_group.add(newSegment)
        all_sprites.add(newSegment)
        self.bodySize = len(self.body)

class Obstacles(object):
    def __init__(self):
        self.obsatacles_arr = []
        self.contador = 0
        self.contador2 = 0
    def tronchos(self, scores, group):
        if scores > 9:
            self.contador += 1
            if self.contador%20 == 0:
                troncho = Troncho()
                troncho.randomPos(group)
                self.obsatacles_arr.append(troncho)
                obstacles.add(troncho)
                all_sprites.add(troncho)      
                self.contador == 0
                self.contador2 += 1
            if self.contador2 == 8:
                    aux = self.obsatacles_arr.pop(0)
                    obstacles.remove(aux)
                    all_sprites.remove(aux)
                    self.contador2 -= 1

    

class main():
    def __init__(self):
        all_sprites.empty()
        obstacles.empty()
        obs = Obstacles()
        
        window = view_snake.Window(WIN_WIDTH, WIN_HEIGHT)
        #myfont = pygame.font.Font('freesansbold.ttf', 16)
        #gameWindow = pygame.display.set_mode([WIN_WIDTH, WIN_HEIGHT])
        #pygame.display.set_caption('Snake Game')
        clock = pygame.time.Clock()
        start = [300,300]
        s = Snake(start)
        apple = Troncho(RED)
        all_sprites.add(apple)
        apple.randomPos(s.body_group)
        
        while True:     
            s.move(apple)
            print(s.ok)
            if not s.ok:
                break
            score = "Score = " + str(len(s.body))
            obs.tronchos(len(s.body), all_sprites)
            window.update(all_sprites, score)
            clock.tick(10)
        
        print("END GAME")
        
            