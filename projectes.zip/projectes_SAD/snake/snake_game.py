import pygame 
import random 
import view_snake



def main():
    view_snake.main()


main()